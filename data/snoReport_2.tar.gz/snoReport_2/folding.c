
#include "folding.h"

#include "fold.h"
#include "part_func.h"

extern int fold_constrained;
extern int noLonelyPairs;

float foldSequence(char *seq, char **structure) {

	noLonelyPairs = 1;
	fold_constrained = 0;
	update_fold_params();

	return fold(seq,*structure); //without constraint
}


float foldCSequence(char *seq, char **structure) {
	float mfec = 0;
	noLonelyPairs = 1;
	fold_constrained = 1;
	update_fold_params();
	

	mfec = fold(seq,*structure); //with constraint
	
	
	
	return mfec;

}

float part_func_fold(char *seq,char **structure){
	int constrained = 1;
	int circular = 0;
	int calcbppm = 1;
	
	return pf_fold(seq,*structure);
	
	
}

