#ifndef FOLDING_H
#define FOLDING_H

#include "structures.h"

float foldSequence(char *seq, char **structure);
float foldCSequence(char *seq, char **structure);


#endif

