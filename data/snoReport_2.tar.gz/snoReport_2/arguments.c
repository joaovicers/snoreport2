#include "arguments.h"

void printHelp(){ 
	puts("SnoReport 2.0\n");
	puts("Identify C/D box and H/ACA box snoRNAs from fasta sequences");
	puts("Usage: snoreport -i <fasta_file> [-CD|-HACA] [-trainCD|-trainHACA]  [OPTIONS]");
	
	puts("-h,--help                Print help and exit.");
	puts("--verbose                Verbose mode.");
	puts("\nGeneral Options\n-i <fasta file>          Inform the input file (fasta file).");
	puts("-CD                      Predict C/D box snoRNAs.");
	puts("-HACA                    Predict H/ACA box snoRNA.");
	puts("--trainCD, --TrainHACA   Generate feature vectors from snoRNA candidates.");
	puts("--positives              Output only positive predictions.");
	puts("-o <file>                Generate a fasta file with the putative snoRNAs found.");
	puts("--PS                     Creates a postScript visualization of the predicted snoRNAs");
		
}


int parseArgs(argument *argS,int numArgs,char **args){
	int i;
	
	if (numArgs == 1){
		printHelp();
	}
	for (i=1;i<numArgs;i++){
		if (strcmp("-i",args[i])==0){
			if (i == numArgs-1)  {
				puts("ERROR! fasta file not found after -i option");
				return 1;
			}
			else if (args[i+1][0] == '-'){
				puts("ERROR! fasta file not found after -i option");
				return 1;
			}
			else if (strlen(args[i+1]) > 1000){
				puts ("ERROR! fasta filename too large!"); return 1;
			}
			strcpy((*argS).fasta,args[i+1]);
			i++;
		}
		else if ((strcmp("-h",args[i])==0) || (strcmp("--help",args[i])==0)){
			printHelp(); return 1;
		}
		else if (strcmp("-o",args[i])==0){
			if (i == numArgs-1)  {
				puts("ERROR! output file not found after -o option");
				return 1;
			}
			else if (args[i+1][0] == '-'){
				puts("ERROR! output file not found after -o option");
				return 1;
			}
			strcpy((*argS).output,args[i+1]);
			(*argS).output_key = 1;
			i++;
		}
		else if (strcmp("-CD",args[i])==0){
			(*argS).cd = 1;
		}
		else if (strcmp("-HACA",args[i])==0){
			(*argS).haca = 1;
		}
		else if (strcmp("--positives",args[i])==0){
			(*argS).positives = 1;
		}
		else if (strcmp("-trainCD",args[i])==0){
			(*argS).trainCD = 1;
		}
		else if (strcmp("-trainHACA",args[i])==0){
			(*argS).trainHACA = 1;
		}
		else if (strcmp("--verbose",args[i])==0){
			(*argS).verbose = 1;
		}
		else if (strcmp("--PS",args[i])==0){
			(*argS).ps = 1;
		}
		else if (strcmp("--class",args[i])==0){
			if (i == numArgs-1)  {
				puts("ERROR! class not defined");
				return 1;
			}
			else if (args[i+1][0] == '-'){
				puts("ERROR! class not defined");
				return 1;
			}
			(*argS).class=atoi(args[i+1]);
			i++;
		}
		else{
			puts("ERROR!!! Invalid argument"); //printHelp
		}
		
	}
	
	return 0;
}
