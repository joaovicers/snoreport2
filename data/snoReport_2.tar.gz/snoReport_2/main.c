/**********************
 * Snoreport v2.0
 * AUTHOR: João Victor de Araujo Oliveira - University of Brasilia
 * 
 * v2.0.0
 * 
 */

#include "structures.h"
#include "arguments.h"
#include "CDbox.h"
#include "HACAbox.h"
#include "svm.h"
 

void resetArgs(argument *argS){
	(*argS).ps = (*argS).haca = (*argS).cd = (*argS).trainCD = (*argS).trainHACA = (*argS).class = (*argS).verbose = (*argS).positives = 0;
	(*argS).output[0]='\0';
	(*argS).output_key = 0;
}


void resetCD(seqinfo *sequence){
	(*sequence).CD.mfe=0;
	(*sequence).CD.mfeC=0;
	(*sequence).CD.GC=0;
	(*sequence).CD.zscore=0;
	(*sequence).CD.Eavg=0;
	(*sequence).CD.Estdv=0;
	(*sequence).CD.ls=0;
	(*sequence).CD.l1=0;
	(*sequence).CD.Dcd=0;
    (*sequence).CD.bpStem=0;
	(*sequence).CD.lu5=0;
	(*sequence).CD.lu3=0;
	(*sequence).CD.stemUnpCbox=0;
	(*sequence).CD.stemUnpDbox=0;
	(*sequence).CD.wc2Stem=0;
	(*sequence).CD.u2Cbox=0;
	(*sequence).CD.Cscore=0;
	(*sequence).CD.Dscore=0;
	(*sequence).CD.Cthreshold=0.62;
	(*sequence).CD.Dthreshold=0.64;
	(*sequence).CD.pred=0;
	(*sequence).CD.probT=0;
	
	(*sequence).HACA.Apos=0;
	(*sequence).HACA.Hpos=0;
	(*sequence).HACA.Ascore=0;
	(*sequence).HACA.Hscore=0;
	(*sequence).HACA.Athreshold = 0.66;
	(*sequence).HACA.Hthreshold = 0.45;
	(*sequence).HACA.zscoreH = 0;
	(*sequence).HACA.zscoreA = 0;
	(*sequence).HACA.LloopSC=0;
	(*sequence).HACA.LloopYC=0;
	(*sequence).HACA.RloopSC=0;
	(*sequence).HACA.RloopYC=0;
	(*sequence).HACA.rloopSym=0;
	(*sequence).HACA.mfe=0;
	(*sequence).HACA.mfeCA=0;
	(*sequence).HACA.mfeCH=0;
	(*sequence).HACA.AC=0;
	(*sequence).HACA.GC=0;
	(*sequence).HACA.GU=0;
	(*sequence).HACA.seqA=NULL;
	(*sequence).HACA.seqH=NULL;
	(*sequence).HACA.conA=NULL;
	(*sequence).HACA.conH=NULL;
	(*sequence).HACA.strCA=NULL;
	(*sequence).HACA.strCH=NULL;
	(*sequence).HACA.pred=0;
	(*sequence).HACA.probT=0;
	
}


/*****************************************Main Function *************************************************/
int main(int argc, char **args){
	argument argS;
	seqinfo sequence;
	FILE *input, *output;
	int flag1=0,i,id=1,aux,cont=0;
	int headerSize,filePos=0;
	char c, fn[400];	
	struct svm_model *CDmodel,*HACAmodel;
	
	output = NULL;
	resetArgs(&argS);
	
	if (parseArgs(&argS,argc,args) == 1){
		return 0; 
	}	
	input = fopen(argS.fasta,"r");
	if (input == NULL){
		printf ("ERROR!! %s couldn't be opened\n",argS.fasta); return 1;
	}
	if (argS.output_key == 1){			
		output = fopen(argS.output,"w");
		if (output == NULL){
			printf("ERROR!! output file with problems\n"); return 1;
		}
	}
		
	if (getenv("SNOREPORTMODELS") == NULL){
		puts("ERROR!! SNOREPORTMODELS environment variable was not defined\n\nPlease define this env variable with the address of the \"models\" folder inside the snoReport 2.0 folder\ne.g. if you installed snoReport on your home use the command: export SNOREPORTMODELS = \"/home/your_user/snoreport2/models/\" ");
		return 1;
	}


	strcpy(fn,getenv("SNOREPORTMODELS"));
	strcat(fn,"21model_CD.model");
	CDmodel = svm_load_model(fn);
	
	if (CDmodel == NULL){
		puts("ERROR!! CDmodel did not open!"); return 1;
	}
	strcpy(fn,getenv("SNOREPORTMODELS"));
	strcat(fn,"12model_HACA");
	HACAmodel = svm_load_model(fn);
	
	if (HACAmodel == NULL){
		puts("ERROR!! HACAmodel did not open!"); return 1;
	}
	
	while (flag1==0){
		
		//*********************read the header of the sequence*********************
		resetCD(&sequence);
		
		headerSize=0;
		filePos = ftell(input);
		while ( (c=getc(input)) && ((c!= EOF) && (c!= '\n'))  ){
			headerSize++;
		}		
		fseek(input,filePos,SEEK_SET);
		sequence.seqName = (char *) calloc(headerSize+1,sizeof(char));
		fscanf(input,"%[^\n]s",sequence.seqName);
		
		if (sequence.seqName[0] != '>'){
			printf("ERROR!! Header need to begin with > %s",sequence.seqName);
			return 0;
		}
		c=getc(input);
		//printf ("%s\n",sequence.seqName);
		cont=0;
		for (aux = 0; aux < strlen(sequence.seqName);aux++){
			if ((sequence.seqName[aux]==' ')|| (sequence.seqName[aux]=='\t')){
				break;
			}else{
				sequence.firstName[cont]=sequence.seqName[aux];
				cont++;
			}
		}
		sequence.firstName[cont]='\0';
		//*********************read the nucleotide sequece*********************
		sequence.tamSeq=0;
		filePos = ftell(input);
		while ( (c=getc(input)) && (c != '>') && (c != EOF)  ){
			if (c != '\n'){
				sequence.tamSeq++;
			}
		}
		sequence.seq = (char *) calloc(sequence.tamSeq+1,sizeof(char));
		fseek(input,filePos,SEEK_SET);
		i=0;
		while ( (c=getc(input)) && (c != '>') && (c != EOF)  ){
			if (c != '\n'){
				sequence.seq[i]=c;
				i++;
			}
		}
		
		if (c == EOF){ //end of file
			flag1=1;
		}
		

		filePos = ftell(input);
		fseek(input,filePos-1,SEEK_SET);
		id =1;
		//*********************Extract features for HACA or CD prediction*********************
		if ((argS.cd == 1)){// && (argS.haca == 0)){ //CD training or prediction
			extractFeaturesCD(&sequence,argS,CDmodel,&output,&id);
			
		}
		if ((argS.haca == 1)){ //&& (argS.cd == 0)){
			extractFeaturesHACA(&sequence,argS,HACAmodel,&output,&id);
		}
		
		
		free(sequence.seq);
		free(sequence.seqName);
	}
	if (argS.output_key == 1){
		fclose(output);
	}
	return 0;
}
