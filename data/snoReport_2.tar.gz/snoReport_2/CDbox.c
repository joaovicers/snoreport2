#include "CDbox.h"
#define basefilename "/home/joaovicers/c_snoReport/models/"

float scoreCp(char *Cpbox){
	int i, m=7;
	float Cpscore =0, box[7][15] = {
		//A		C		G		U
		{0.3347,0.2754,0.2590,0.1308},
		{0.0277,0.0360,0.0289,0.9073},
		{0.0206,0.0372,0.8127,0.1294},
		{0.6783,0.0668,0.1734,0.0814},
		{0.1378,0.0354,0.1818,0.6448},
		{0.1070,0.0260,0.5936,0.2733},
		{0.6618,0.0673,0.1569,0.1139}

	};

	box[0][4]  = (box[0][0]+box[0][2])/2; // R
	box[0][5]  = (box[0][1]+box[0][3])/2; // Y
	box[0][6]  = (box[0][0]+box[0][1])/2; // M
	box[0][7]  = (box[0][2]+box[0][3])/2; // K
	box[0][8]  = (box[0][0]+box[0][3])/2; // W
	box[0][9]  = (box[0][1]+box[0][2])/2; // S
	box[0][10] = (box[0][1]+box[0][2]+box[0][3])/3; // B
	box[0][11] = (box[0][0]+box[0][2]+box[0][3])/3; // D
	box[0][12] = (box[0][0]+box[0][1]+box[0][3])/3; // H
	box[0][13] = (box[0][0]+box[0][1]+box[0][2])/3; // V
	box[0][14] = 0.25; //N
	box[1][4]  = (box[1][0]+box[1][2])/2; // R
	box[1][5]  = (box[1][1]+box[1][3])/2; // Y
	box[1][6]  = (box[1][0]+box[1][1])/2; // M
	box[1][7]  = (box[1][2]+box[1][3])/2; // K
	box[1][8]  = (box[1][0]+box[1][3])/2; // W
	box[1][9]  = (box[1][1]+box[1][2])/2; // S
	box[1][10] = (box[1][1]+box[1][2]+box[1][3])/3; // B
	box[1][11] = (box[1][0]+box[1][2]+box[1][3])/3; // D
	box[1][12] = (box[1][0]+box[1][1]+box[1][3])/3; // H
	box[1][13] = (box[1][0]+box[1][1]+box[1][2])/3; // V
	box[1][14] = 0.25; //N
	box[2][4]  = (box[2][0]+box[2][2])/2; // R
	box[2][5]  = (box[2][1]+box[2][3])/2; // Y
	box[2][6]  = (box[2][0]+box[2][1])/2; // M
	box[2][7]  = (box[2][2]+box[2][3])/2; // K
	box[2][8]  = (box[2][0]+box[2][3])/2; // W
	box[2][9]  = (box[2][1]+box[2][2])/2; // S
	box[2][10] = (box[2][1]+box[2][2]+box[2][3])/3; // B
	box[2][11] = (box[2][0]+box[2][2]+box[2][3])/3; // D
	box[2][12] = (box[2][0]+box[2][1]+box[2][3])/3; // H
	box[2][13] = (box[2][0]+box[2][1]+box[2][2])/3; // V
	box[2][14] = 0.25; //N
	box[3][4]  = (box[3][0]+box[3][2])/2; // R
	box[3][5]  = (box[3][1]+box[3][3])/2; // Y
	box[3][6]  = (box[3][0]+box[3][1])/2; // M
	box[3][7]  = (box[3][2]+box[3][3])/2; // K
	box[3][8]  = (box[3][0]+box[3][3])/2; // W
	box[3][9]  = (box[3][1]+box[3][2])/2; // S
	box[3][10] = (box[3][1]+box[3][2]+box[3][3])/3; // B
	box[3][11] = (box[3][0]+box[3][2]+box[3][3])/3; // D
	box[3][12] = (box[3][0]+box[3][1]+box[3][3])/3; // H
	box[3][13] = (box[3][0]+box[3][1]+box[3][2])/3; // V
	box[3][14] = 0.25; //N
	box[4][4]  = (box[4][0]+box[4][2])/2; // R
	box[4][5]  = (box[4][1]+box[4][3])/2; // Y
	box[4][6]  = (box[4][0]+box[4][1])/2; // M
	box[4][7]  = (box[4][2]+box[4][3])/2; // K
	box[4][8]  = (box[4][0]+box[4][3])/2; // W
	box[4][9]  = (box[4][1]+box[4][2])/2; // S
	box[4][10] = (box[4][1]+box[4][2]+box[4][3])/3; // B
	box[4][11] = (box[4][0]+box[4][2]+box[4][3])/3; // D
	box[4][12] = (box[4][0]+box[4][1]+box[4][3])/3; // H
	box[4][13] = (box[4][0]+box[4][1]+box[4][2])/3; // V
	box[4][14] = 0.25; //N
	box[5][4]  = (box[5][0]+box[5][2])/2; // R
	box[5][5]  = (box[5][1]+box[5][3])/2; // Y
	box[5][6]  = (box[5][0]+box[5][1])/2; // M
	box[5][7]  = (box[5][2]+box[5][3])/2; // K
	box[5][8]  = (box[5][0]+box[5][3])/2; // W
	box[5][9]  = (box[5][1]+box[5][2])/2; // S
	box[5][10] = (box[5][1]+box[5][2]+box[5][3])/3; // B
	box[5][11] = (box[5][0]+box[5][2]+box[5][3])/3; // D
	box[5][12] = (box[5][0]+box[5][1]+box[5][3])/3; // H
	box[5][13] = (box[5][0]+box[5][1]+box[5][2])/3; // V
	box[5][14] = 0.25; //N
	box[6][4]  = (box[4][0]+box[4][2])/2; // R
	box[6][5]  = (box[4][1]+box[4][3])/2; // Y
	box[6][6]  = (box[4][0]+box[4][1])/2; // M
	box[6][7]  = (box[4][2]+box[4][3])/2; // K
	box[6][8]  = (box[4][0]+box[4][3])/2; // W
	box[6][9]  = (box[4][1]+box[4][2])/2; // S
	box[6][10] = (box[4][1]+box[4][2]+box[4][3])/3; // B
	box[6][11] = (box[4][0]+box[4][2]+box[4][3])/3; // D
	box[6][12] = (box[4][0]+box[4][1]+box[4][3])/3; // H
	box[6][13] = (box[4][0]+box[4][1]+box[4][2])/3; // V
	box[6][14] = 0.25; //N

	for(i=0; i<m; i++) {
		if(Cpbox[i] == 'A') { Cpscore += box[i][0]; }
		else if(Cpbox[i] == 'C') { Cpscore += box[i][1]; }
		else if(Cpbox[i] == 'G') { Cpscore += box[i][2]; }
		else if(Cpbox[i] == 'U') { Cpscore += box[i][3]; }
		else if(Cpbox[i] == 'T') { Cpscore += box[i][3]; }
		else if(Cpbox[i] == 'R') { Cpscore += box[i][4]; }
		else if(Cpbox[i] == 'Y') { Cpscore += box[i][5]; }
		else if(Cpbox[i] == 'M') { Cpscore += box[i][6]; }
		else if(Cpbox[i] == 'K') { Cpscore += box[i][7]; }
		else if(Cpbox[i] == 'W') { Cpscore += box[i][8]; }
		else if(Cpbox[i] == 'S') { Cpscore += box[i][9]; }
		else if(Cpbox[i] == 'B') { Cpscore += box[i][10]; }
		else if(Cpbox[i] == 'D') { Cpscore += box[i][11]; }
		else if(Cpbox[i] == 'H') { Cpscore += box[i][12]; }
		else if(Cpbox[i] == 'V') { Cpscore += box[i][13]; }
		else { Cpscore += box[i][14]; }
	}
	Cpscore /= m;

	return Cpscore;

}


float scoreDp( char *Dpbox){
	int i, m=4;
	float Dpscore=0, box[4][15]= {
			//A			C		G		U
			{0.1614,0.6149,0.1592,0.0643},
			{0.0730,0.0298,0.0203,0.8768},
			{0.0204,0.0114,0.9378,0.0302},
			{0.9121,0.0322,0.0269,0.0287},	//4
	};


	box[0][4]  = (box[0][0]+box[0][2])/2; // R
		box[0][5]  = (box[0][1]+box[0][3])/2; // Y
		box[0][6]  = (box[0][0]+box[0][1])/2; // M
		box[0][7]  = (box[0][2]+box[0][3])/2; // K
		box[0][8]  = (box[0][0]+box[0][3])/2; // W
		box[0][9]  = (box[0][1]+box[0][2])/2; // S
		box[0][10] = (box[0][1]+box[0][2]+box[0][3])/3; // B
		box[0][11] = (box[0][0]+box[0][2]+box[0][3])/3; // D
		box[0][12] = (box[0][0]+box[0][1]+box[0][3])/3; // H
		box[0][13] = (box[0][0]+box[0][1]+box[0][2])/3; // V
		box[0][14] = 0.25; //N
		box[1][4]  = (box[1][0]+box[1][2])/2; // R
		box[1][5]  = (box[1][1]+box[1][3])/2; // Y
		box[1][6]  = (box[1][0]+box[1][1])/2; // M
		box[1][7]  = (box[1][2]+box[1][3])/2; // K
		box[1][8]  = (box[1][0]+box[1][3])/2; // W
		box[1][9]  = (box[1][1]+box[1][2])/2; // S
		box[1][10] = (box[1][1]+box[1][2]+box[1][3])/3; // B
		box[1][11] = (box[1][0]+box[1][2]+box[1][3])/3; // D
		box[1][12] = (box[1][0]+box[1][1]+box[1][3])/3; // H
		box[1][13] = (box[1][0]+box[1][1]+box[1][2])/3; // V
		box[1][14] = 0.25; //N
		box[2][4]  = (box[2][0]+box[2][2])/2; // R
		box[2][5]  = (box[2][1]+box[2][3])/2; // Y
		box[2][6]  = (box[2][0]+box[2][1])/2; // M
		box[2][7]  = (box[2][2]+box[2][3])/2; // K
		box[2][8]  = (box[2][0]+box[2][3])/2; // W
		box[2][9]  = (box[2][1]+box[2][2])/2; // S
		box[2][10] = (box[2][1]+box[2][2]+box[2][3])/3; // B
		box[2][11] = (box[2][0]+box[2][2]+box[2][3])/3; // D
		box[2][12] = (box[2][0]+box[2][1]+box[2][3])/3; // H
		box[2][13] = (box[2][0]+box[2][1]+box[2][2])/3; // V
		box[2][14] = 0.25; //N
		box[3][4]  = (box[3][0]+box[3][2])/2; // R
		box[3][5]  = (box[3][1]+box[3][3])/2; // Y
		box[3][6]  = (box[3][0]+box[3][1])/2; // M
		box[3][7]  = (box[3][2]+box[3][3])/2; // K
		box[3][8]  = (box[3][0]+box[3][3])/2; // W
		box[3][9]  = (box[3][1]+box[3][2])/2; // S
		box[3][10] = (box[3][1]+box[3][2]+box[3][3])/3; // B
		box[3][11] = (box[3][0]+box[3][2]+box[3][3])/3; // D
		box[3][12] = (box[3][0]+box[3][1]+box[3][3])/3; // H
		box[3][13] = (box[3][0]+box[3][1]+box[3][2])/3; // V
		box[3][14] = 0.25; //N

		for(i=0; i<m; i++) {
			if(Dpbox[i] == 'A') { Dpscore += box[i][0]; }
			else if(Dpbox[i] == 'C') { Dpscore += box[i][1]; }
			else if(Dpbox[i] == 'G') { Dpscore += box[i][2]; }
			else if(Dpbox[i] == 'U') { Dpscore += box[i][3]; }
			else if(Dpbox[i] == 'T') { Dpscore += box[i][3]; }
			else if(Dpbox[i] == 'R') { Dpscore += box[i][4]; }
			else if(Dpbox[i] == 'Y') { Dpscore += box[i][5]; }
			else if(Dpbox[i] == 'M') { Dpscore += box[i][6]; }
			else if(Dpbox[i] == 'K') { Dpscore += box[i][7]; }
			else if(Dpbox[i] == 'W') { Dpscore += box[i][8]; }
			else if(Dpbox[i] == 'S') { Dpscore += box[i][9]; }
			else if(Dpbox[i] == 'B') { Dpscore += box[i][10]; }
			else if(Dpbox[i] == 'D') { Dpscore += box[i][11]; }
			else if(Dpbox[i] == 'H') { Dpscore += box[i][12]; }
			else if(Dpbox[i] == 'V') { Dpscore += box[i][13]; }
			else { Dpscore += box[i][14]; }
		}
		Dpscore /= m;

		return Dpscore;
}


float scoreC(char *Cbox){
	int i, m=7;
	float Cscore=0, box[7][15] = {
		//	A		C		G		U
			{0.3922, 0.1569, 0.2549, 0.1961},		//1
			{0.0784, 0.0980, 0.0588, 0.7647},		//2
			{0.0000, 0.0392, 0.9412, 0.0196},		//3
			{0.9608, 0.0196, 0.0000, 0.0196},		//4
			{0.0588, 0.0784, 0.1176, 0.7451},		//5
			{0.0980, 0.0000, 0.8235, 0.0784},		//6
			{0.7451, 0.0588, 0.1176, 0.0784}		//7

	};
	box[0][4]  = (box[0][0]+box[0][2])/2; // R
	box[0][5]  = (box[0][1]+box[0][3])/2; // Y
	box[0][6]  = (box[0][0]+box[0][1])/2; // M
	box[0][7]  = (box[0][2]+box[0][3])/2; // K
	box[0][8]  = (box[0][0]+box[0][3])/2; // W
	box[0][9]  = (box[0][1]+box[0][2])/2; // S
	box[0][10] = (box[0][1]+box[0][2]+box[0][3])/3; // B
	box[0][11] = (box[0][0]+box[0][2]+box[0][3])/3; // D
	box[0][12] = (box[0][0]+box[0][1]+box[0][3])/3; // H
	box[0][13] = (box[0][0]+box[0][1]+box[0][2])/3; // V
	box[0][14] = 0.25; //N
	box[1][4]  = (box[1][0]+box[1][2])/2; // R
	box[1][5]  = (box[1][1]+box[1][3])/2; // Y
	box[1][6]  = (box[1][0]+box[1][1])/2; // M
	box[1][7]  = (box[1][2]+box[1][3])/2; // K
	box[1][8]  = (box[1][0]+box[1][3])/2; // W
	box[1][9]  = (box[1][1]+box[1][2])/2; // S
	box[1][10] = (box[1][1]+box[1][2]+box[1][3])/3; // B
	box[1][11] = (box[1][0]+box[1][2]+box[1][3])/3; // D
	box[1][12] = (box[1][0]+box[1][1]+box[1][3])/3; // H
	box[1][13] = (box[1][0]+box[1][1]+box[1][2])/3; // V
	box[1][14] = 0.25; //N
	box[2][4]  = (box[2][0]+box[2][2])/2; // R
	box[2][5]  = (box[2][1]+box[2][3])/2; // Y
	box[2][6]  = (box[2][0]+box[2][1])/2; // M
	box[2][7]  = (box[2][2]+box[2][3])/2; // K
	box[2][8]  = (box[2][0]+box[2][3])/2; // W
	box[2][9]  = (box[2][1]+box[2][2])/2; // S
	box[2][10] = (box[2][1]+box[2][2]+box[2][3])/3; // B
	box[2][11] = (box[2][0]+box[2][2]+box[2][3])/3; // D
	box[2][12] = (box[2][0]+box[2][1]+box[2][3])/3; // H
	box[2][13] = (box[2][0]+box[2][1]+box[2][2])/3; // V
	box[2][14] = 0.25; //N
	box[3][4]  = (box[3][0]+box[3][2])/2; // R
	box[3][5]  = (box[3][1]+box[3][3])/2; // Y
	box[3][6]  = (box[3][0]+box[3][1])/2; // M
	box[3][7]  = (box[3][2]+box[3][3])/2; // K
	box[3][8]  = (box[3][0]+box[3][3])/2; // W
	box[3][9]  = (box[3][1]+box[3][2])/2; // S
	box[3][10] = (box[3][1]+box[3][2]+box[3][3])/3; // B
	box[3][11] = (box[3][0]+box[3][2]+box[3][3])/3; // D
	box[3][12] = (box[3][0]+box[3][1]+box[3][3])/3; // H
	box[3][13] = (box[3][0]+box[3][1]+box[3][2])/3; // V
	box[3][14] = 0.25; //N
	box[4][4]  = (box[4][0]+box[4][2])/2; // R
	box[4][5]  = (box[4][1]+box[4][3])/2; // Y
	box[4][6]  = (box[4][0]+box[4][1])/2; // M
	box[4][7]  = (box[4][2]+box[4][3])/2; // K
	box[4][8]  = (box[4][0]+box[4][3])/2; // W
	box[4][9]  = (box[4][1]+box[4][2])/2; // S
	box[4][10] = (box[4][1]+box[4][2]+box[4][3])/3; // B
	box[4][11] = (box[4][0]+box[4][2]+box[4][3])/3; // D
	box[4][12] = (box[4][0]+box[4][1]+box[4][3])/3; // H
	box[4][13] = (box[4][0]+box[4][1]+box[4][2])/3; // V
	box[4][14] = 0.25; //N
	box[5][4]  = (box[5][0]+box[5][2])/2; // R
	box[5][5]  = (box[5][1]+box[5][3])/2; // Y
	box[5][6]  = (box[5][0]+box[5][1])/2; // M
	box[5][7]  = (box[5][2]+box[5][3])/2; // K
	box[5][8]  = (box[5][0]+box[5][3])/2; // W
	box[5][9]  = (box[5][1]+box[5][2])/2; // S
	box[5][10] = (box[5][1]+box[5][2]+box[5][3])/3; // B
	box[5][11] = (box[5][0]+box[5][2]+box[5][3])/3; // D
	box[5][12] = (box[5][0]+box[5][1]+box[5][3])/3; // H
	box[5][13] = (box[5][0]+box[5][1]+box[5][2])/3; // V
	box[5][14] = 0.25; //N
	box[6][4]  = (box[4][0]+box[4][2])/2; // R
	box[6][5]  = (box[4][1]+box[4][3])/2; // Y
	box[6][6]  = (box[4][0]+box[4][1])/2; // M
	box[6][7]  = (box[4][2]+box[4][3])/2; // K
	box[6][8]  = (box[4][0]+box[4][3])/2; // W
	box[6][9]  = (box[4][1]+box[4][2])/2; // S
	box[6][10] = (box[4][1]+box[4][2]+box[4][3])/3; // B
	box[6][11] = (box[4][0]+box[4][2]+box[4][3])/3; // D
	box[6][12] = (box[4][0]+box[4][1]+box[4][3])/3; // H
	box[6][13] = (box[4][0]+box[4][1]+box[4][2])/3; // V
	box[6][14] = 0.25; //N

	for(i=0; i<m; i++) {
		if(Cbox[i] == 'A') { Cscore += box[i][0]; }
		else if(Cbox[i] == 'C') { Cscore += box[i][1]; }
		else if(Cbox[i] == 'G') { Cscore += box[i][2]; }
		else if(Cbox[i] == 'U') { Cscore += box[i][3]; }
		else if(Cbox[i] == 'T') { Cscore += box[i][3]; }
		else if(Cbox[i] == 'R') { Cscore += box[i][4]; }
		else if(Cbox[i] == 'Y') { Cscore += box[i][5]; }
		else if(Cbox[i] == 'M') { Cscore += box[i][6]; }
		else if(Cbox[i] == 'K') { Cscore += box[i][7]; }
		else if(Cbox[i] == 'W') { Cscore += box[i][8]; }
		else if(Cbox[i] == 'S') { Cscore += box[i][9]; }
		else if(Cbox[i] == 'B') { Cscore += box[i][10]; }
		else if(Cbox[i] == 'D') { Cscore += box[i][11]; }
		else if(Cbox[i] == 'H') { Cscore += box[i][12]; }
		else if(Cbox[i] == 'V') { Cscore += box[i][13]; }
		else { Cscore += box[i][14]; }
	}
	Cscore /= m;

	return Cscore;
}

float scoreD( char *Dbox){
	int i, m=4;
	float Dscore = 0, box[4][15]= {
			//A		C		G		U
			{0.1250, 0.6250, 0.1250, 0.1250},	//1
			{0.1250, 0.1250, 0.1250, 0.6250},	//2
			{0.0000, 0.0000, 1.0000, 0.0000},	//3
			{0.8750, 0.1250, 0.0000, 0.0000},	//4
	};


	box[0][4]  = (box[0][0]+box[0][2])/2; // R
	box[0][5]  = (box[0][1]+box[0][3])/2; // Y
	box[0][6]  = (box[0][0]+box[0][1])/2; // M
	box[0][7]  = (box[0][2]+box[0][3])/2; // K
	box[0][8]  = (box[0][0]+box[0][3])/2; // W
	box[0][9]  = (box[0][1]+box[0][2])/2; // S
	box[0][10] = (box[0][1]+box[0][2]+box[0][3])/3; // B
	box[0][11] = (box[0][0]+box[0][2]+box[0][3])/3; // D
	box[0][12] = (box[0][0]+box[0][1]+box[0][3])/3; // H
	box[0][13] = (box[0][0]+box[0][1]+box[0][2])/3; // V
	box[0][14] = 0.25; //N
	box[1][4]  = (box[1][0]+box[1][2])/2; // R
	box[1][5]  = (box[1][1]+box[1][3])/2; // Y
	box[1][6]  = (box[1][0]+box[1][1])/2; // M
	box[1][7]  = (box[1][2]+box[1][3])/2; // K
	box[1][8]  = (box[1][0]+box[1][3])/2; // W
	box[1][9]  = (box[1][1]+box[1][2])/2; // S
	box[1][10] = (box[1][1]+box[1][2]+box[1][3])/3; // B
	box[1][11] = (box[1][0]+box[1][2]+box[1][3])/3; // D
	box[1][12] = (box[1][0]+box[1][1]+box[1][3])/3; // H
	box[1][13] = (box[1][0]+box[1][1]+box[1][2])/3; // V
	box[1][14] = 0.25; //N
	box[2][4]  = (box[2][0]+box[2][2])/2; // R
	box[2][5]  = (box[2][1]+box[2][3])/2; // Y
	box[2][6]  = (box[2][0]+box[2][1])/2; // M
	box[2][7]  = (box[2][2]+box[2][3])/2; // K
	box[2][8]  = (box[2][0]+box[2][3])/2; // W
	box[2][9]  = (box[2][1]+box[2][2])/2; // S
	box[2][10] = (box[2][1]+box[2][2]+box[2][3])/3; // B
	box[2][11] = (box[2][0]+box[2][2]+box[2][3])/3; // D
	box[2][12] = (box[2][0]+box[2][1]+box[2][3])/3; // H
	box[2][13] = (box[2][0]+box[2][1]+box[2][2])/3; // V
	box[2][14] = 0.25; //N
	box[3][4]  = (box[3][0]+box[3][2])/2; // R
	box[3][5]  = (box[3][1]+box[3][3])/2; // Y
	box[3][6]  = (box[3][0]+box[3][1])/2; // M
	box[3][7]  = (box[3][2]+box[3][3])/2; // K
	box[3][8]  = (box[3][0]+box[3][3])/2; // W
	box[3][9]  = (box[3][1]+box[3][2])/2; // S
	box[3][10] = (box[3][1]+box[3][2]+box[3][3])/3; // B
	box[3][11] = (box[3][0]+box[3][2]+box[3][3])/3; // D
	box[3][12] = (box[3][0]+box[3][1]+box[3][3])/3; // H
	box[3][13] = (box[3][0]+box[3][1]+box[3][2])/3; // V
	box[3][14] = 0.25; //N

	for(i=0; i<m; i++) {
		if(Dbox[i] == 'A') { Dscore += box[i][0]; }
		else if(Dbox[i] == 'C') { Dscore += box[i][1]; }
		else if(Dbox[i] == 'G') { Dscore += box[i][2]; }
		else if(Dbox[i] == 'U') { Dscore += box[i][3]; }
		else if(Dbox[i] == 'T') { Dscore += box[i][3]; }
		else if(Dbox[i] == 'R') { Dscore += box[i][4]; }
		else if(Dbox[i] == 'Y') { Dscore += box[i][5]; }
		else if(Dbox[i] == 'M') { Dscore += box[i][6]; }
		else if(Dbox[i] == 'K') { Dscore += box[i][7]; }
		else if(Dbox[i] == 'W') { Dscore += box[i][8]; }
		else if(Dbox[i] == 'S') { Dscore += box[i][9]; }
		else if(Dbox[i] == 'B') { Dscore += box[i][10]; }
		else if(Dbox[i] == 'D') { Dscore += box[i][11]; }
		else if(Dbox[i] == 'H') { Dscore += box[i][12]; }
		else if(Dbox[i] == 'V') { Dscore += box[i][13]; }
		else { Dscore += box[i][14]; }
	}
	Dscore /= m;

	return Dscore;

}


/************************Verify if 2 nt are WC basepairs**********************/
int WC_test(char c, char d){
	switch(c){
		case 'A':
		case 'a':
			if ((d == 'T') || (d == 't') || (d == 'U') || (d == 'u') ){
				return 1;
			}
			return 0;
			break;
		case 'T':
		case 't':
			if ((d == 'a') || (d == 'A')){
				return 1;
			}
			return 0;
			break;
		case 'U':
		case 'u':
			if ((d == 'a') || (d == 'A')){
				return 1;
			}
			return 0;
			break;
		case 'C':
		case 'c':
			if ((d == 'g') || (d == 'G')){
				return 1;
			}
			return 0;		
			break;
		case 'G':
		case 'g':
			if ((d == 'c') || (d == 'C')){
				return 1;
			}
			return 0;
			break;
		default:
			return 0;
	}
	return 0;
}

float GCcontent(char *s){
	int i,size;
	float g,c,a,t;
	float gc=0;
	g=c=a=t=0;
	
	size = strlen(s);
	
	for (i=0; i<size;i++){
		switch(s[i]){
			case 'a':
			case 'A':
				a++;
				break;
			case 't':
			case 'T':	
			case 'U':	
			case 'u':	
				t++;
				break;
			case 'c':
			case 'C':
				c++;
				break;
			case 'g':
			case 'G':
				g++;
				break;
		}
		
	}
	gc = (float) ((g+c)/(a+t+c+g));
	return gc;
}

/*******************************PrintFeatureVector*****************************************************/
void printCDfeatures(CDinfo CD, argument argS){

	printf("%d 1:%f",argS.class,CD.mfe);
	printf(" 2:%f",CD.mfeC);
	printf(" 3:%f",CD.Eavg);
	printf(" 4:%f",CD.Estdv);
	printf(" 5:%d",CD.ls);
	printf(" 6:%d",CD.Dcd);
	printf(" 7:%f",CD.Cscore);
	printf(" 8:%f",CD.Dscore);
	printf(" 9:%f",CD.GC);
	printf(" 10:%f",CD.zscore);
	printf(" 11:%d",CD.bpStem);
	printf(" 12:%d",CD.lu5);
	printf(" 13:%d",CD.lu3);
	printf(" 14:%d",CD.stemUnpCbox);
	printf(" 15:%d",CD.stemUnpDbox);
	printf(" 16:%d\n",CD.wc2Stem);									
											
}											
									
/************************************Extract FeaturesCD***********************************************/
int extractFeaturesCD(seqinfo *sequence, argument argS, struct svm_model *CDmodel,FILE **output,int * id){
	int i,j,k,q,m,ok,l,r,cont=0,aux;
	int start,end,firstStem;
	char tmp[500];
	
	
	
	if (argS.verbose){
			printf("Sequence name: %s\n",(*sequence).seqName);
	}
	
	
	/******************Scan sequence to find Box C candidates*********************/
	for (i=4;i<(*sequence).tamSeq-14; i++){
		memcpy((*sequence).CD.Cbox,(*sequence).seq+i,7);
		(*sequence).CD.Cbox[7]='\0';
		(*sequence).CD.Cscore = scoreC((*sequence).CD.Cbox);
		(*sequence).CD.CPos=i;
		
	
		if ((*sequence).CD.Cscore  > (*sequence).CD.Cthreshold ){						
			/*************Scan sequence to find ALL D box candidates****************/
			if (argS.verbose){
				printf ("\tC box  = %s pos %d score = %f\n",(*sequence).CD.Cbox,(*sequence).CD.CPos+1, (*sequence).CD.Cscore);
			}
			for (j=i+10;j<=(*sequence).tamSeq-7;j++){				
				if (j-i+10 > 200){
					break;
				}
				memcpy((*sequence).CD.Dbox,(*sequence).seq+j,4);
				(*sequence).CD.Dbox[4]='\0';
				(*sequence).CD.Dscore = scoreD((*sequence).CD.Dbox);
				(*sequence).CD.DPos=j;
				
				if ( (*sequence).CD.Dscore  > (*sequence).CD.Dthreshold ){
					if (argS.verbose){
						printf ("\t\tD box  = %s pos = %d score = %f\n",(*sequence).CD.Dbox,(*sequence).CD.DPos+1, (*sequence).CD.Dscore);	
					}
					/************************C and D boxes analysis ********************/
					//kink turn
					if ( (((*sequence).CD.Dbox[2] == 'G') || ((*sequence).CD.Dbox[2] == 'g')) &&
					     (((*sequence).CD.Cbox[3] == 'A') || ((*sequence).CD.Cbox[3] == 'a')) &&
					     (((*sequence).CD.Dbox[3] == 'A') || ((*sequence).CD.Dbox[3] == 'a')) &&
					     (((*sequence).CD.Cbox[2] == 'G') || ((*sequence).CD.Cbox[2] == 'g')) ){
						// U test
						if ( ((*sequence).CD.Cbox[4] == 'T') || ((*sequence).CD.Cbox[4] == 'U') ||
							 ((*sequence).CD.Cbox[4] == 't') || ((*sequence).CD.Cbox[4] == 'u') ||
						     ((*sequence).CD.Dbox[1] == 'T') || ((*sequence).CD.Dbox[1] == 'U') ||
						     ((*sequence).CD.Dbox[1] == 't') || ((*sequence).CD.Dbox[1] == 'u') ){
							 //WC test
							 if ( WC_test((*sequence).CD.Dbox[0],(*sequence).CD.Cbox[5])){
								 /****************************FOLDING**********************/
								 start=(*sequence).CD.CPos-10;
								 end=(*sequence).CD.DPos+14;
								 
								 if (start < 0){
									start=0;
								 }
								 if (end > (*sequence).tamSeq)  {
									 end = (*sequence).tamSeq;
								 }
								 
								 (*sequence).CD.cand = (char *) calloc(end-start+1, sizeof(char));
								 memcpy((*sequence).CD.cand,(*sequence).seq+start,end-start);
								 (*sequence).str = (char *) calloc(end-start+1,sizeof(char));
								 (*sequence).Cstr = (char *) calloc(end-start+1,sizeof(char));
								 
								 //without constraint
								 (*sequence).CD.mfe = foldSequence((*sequence).CD.cand,&(*sequence).str);
								 
								 for (k=0;k< end-start;k++){
									(*sequence).str[k]='.';
								 }
								 //constraint the loop between C and D boxes 
								 for(k=(*sequence).CD.CPos-start;k<(*sequence).CD.DPos-start+4;k++){
									 (*sequence).str[k]='x';
								 } 
								 strcpy((*sequence).Cstr,(*sequence).str);
								 //Folding with constraint
								 (*sequence).CD.mfeC = foldCSequence((*sequence).CD.cand,&(*sequence).Cstr);
								 							
								 if ((argS.verbose)){
									  printf("\t\t\t%s\n\t\t\t%s\n\t\t\t%s\n",(*sequence).CD.cand,(*sequence).str,(*sequence).Cstr);
								 }
								/*
								 if ((*sequence).CD.mfeC == 0){
									//printf("%s %d %d\n",(*sequence).seqName,(*sequence).CD.CPos+1,(*sequence).CD.DPos+1);
										
									//fold using part function and bp matrix
									strcpy((*sequence).Cstr,(*sequence).str);
									part_func_fold((*sequence).CD.cand,&(*sequence).Cstr);
									
									//printf ("-> %s\n",(*sequence).Cstr);
									for  (q = 0; q < strlen((*sequence).Cstr);q++){
										switch((*sequence).Cstr[q]){
											case '{':
												(*sequence).Cstr[q]='(';
												break;
											case '}':
												(*sequence).Cstr[q]=')';
											case ',':
											case '|':
												if (q > strlen((*sequence).Cstr)/2){
													(*sequence).Cstr[q]=')';
												}
												else{
													(*sequence).Cstr[q]='(';
												}	
										}
									}
									//printf ("-> %s\n",(*sequence).Cstr);
								 }*/
							 
								 /********************STRUCTURE FILTER ******************************/
								 //Verify if the candidate have one loop between C and D box
								 ok=1;
								 for (k=(*sequence).CD.CPos-start;k<(*sequence).CD.DPos-start+4;k++){
									 if ( (*sequence).Cstr[k] != '.'  ){
										ok=0;
										break; 
									 }
								 }
								 //Verify if it have stem before C box (RUGAUGA) and after D box
								 if (ok == 1){
									l=r=0;
									for (k=(*sequence).CD.CPos-start; k>=0;k--){
										if ( (*sequence).Cstr[k] == '('  ){
											l++;
										}
										else if ( (*sequence).Cstr[k] == ')'   ){
											ok = 0;
											break;
										}
									}
									
									for(k=(*sequence).CD.DPos-start+4;k<strlen((*sequence).Cstr);k++){
										if ( (*sequence).Cstr[k] == ')'  ){
											r++;
										}
										else if ( (*sequence).Cstr[k] == '('   ){
											ok = 0;
											break;
										}
									} 
									if ((ok == 1) && (l!=0) && (l==r)){
										/*****************extract features**************************/
										// printf("----->\n%s\n%s\n%s\n",(*sequence).CD.cand,(*sequence).str,(*sequence).Cstr);
										//stem attributes
										l=r=0;
										firstStem=0;
										(*sequence).CD.lu5 = (*sequence).CD.ls = 0;
										(*sequence).CD.stemUnpCbox=0;
										ok=0;
										for (k=(*sequence).CD.CPos-start-1; k>=0;k--){
											if ( (*sequence).Cstr[k] == '('  ){
												l++;
												ok=1;
												
											}
											else if ( ((*sequence).Cstr[k] == '.'  ) && (ok ==1)){
												if (firstStem == 0){
													(*sequence).CD.ls = l;
													firstStem =1;
												}
												(*sequence).CD.lu5++;
												
											}
											else if (((*sequence).Cstr[k] == '.'  ) && (ok ==0)){
												(*sequence).CD.stemUnpCbox++;
											}
										}
										if (firstStem == 0){
											(*sequence).CD.ls = l;
										}
										(*sequence).CD.bpStem=l;
										//discard unpaired bases before start the stem
										for (k=0; k<(*sequence).CD.CPos-start;k++){
											if (((*sequence).Cstr[k] == '.'  )){
												(*sequence).CD.lu5--;
											}
											else{
												break;
											}
										}
										
										//
										l=r=0;
										firstStem=0;
										(*sequence).CD.lu3=0;
										ok =0;
										(*sequence).CD.stemUnpDbox=0;
										for(k=(*sequence).CD.DPos-start+4;k<strlen((*sequence).Cstr);k++){
											if ( (*sequence).Cstr[k] == ')'  ){
												r++;
												ok=1;
												
											}
											else if (((*sequence).Cstr[k] == '.' ) && (ok ==1)){
												if (firstStem == 0){
													if (r < (*sequence).CD.ls){
														(*sequence).CD.ls = r;
													}
													(*sequence).CD.lu3++;
												}
											}
											else if (((*sequence).Cstr[k] == '.' ) && (ok ==0)){
												(*sequence).CD.stemUnpDbox++;
											}
										}
										if (firstStem == 0){
											if (r < (*sequence).CD.ls){
												(*sequence).CD.ls = r;
											}
										}
										for(k=strlen((*sequence).Cstr)-1;k>=(*sequence).CD.DPos-start+4;k--){
											if ((*sequence).Cstr[k] == '.' ){
												(*sequence).CD.lu3--;
											}
											else{
												break;
											}
										}										
										
										//Box attributes	
										if (WC_test((*sequence).CD.Cbox[6], (*sequence).seq[(*sequence).CD.DPos -1]) ){
											(*sequence).CD.wc2Stem=1;
										}
										else{
											(*sequence).CD.wc2Stem=0;
										}
										(*sequence).CD.Dcd=(*sequence).CD.DPos-((*sequence).CD.CPos+7);
										
										//GC content
										(*sequence).CD.GC = GCcontent((*sequence).CD.cand);
										  
										  
										//zscore  
																			  
										regression_svm_init(getenv("SNOREPORTMODELS"));
										predict_values((*sequence).CD.cand,&((*sequence).CD.Eavg),&((*sequence).CD.Estdv));
										(*sequence).CD.zscore = mfe_zscore((*sequence).CD.cand, (*sequence).CD.mfeC);
										regression_svm_free();//
										
										 
										if (argS.trainCD){
											printf("# %s C=%d D=%d\n",(*sequence).seqName,(*sequence).CD.CPos+1,(*sequence).CD.DPos+1);  
											printCDfeatures((*sequence).CD,argS);
										}
										else{
											 (*sequence).CD.pred = predictCD(&(*sequence).CD,CDmodel);
											 if (argS.positives == 1){
												if ((*sequence).CD.pred == 1){
													printf("%s_%d\t%d\t%d\t%s\t%d\t%s\t%d\t%.2f\t C/D box snoRNA\n",(*sequence).firstName,*id,start+1,end+1,(*sequence).CD.Cbox,(*sequence).CD.CPos+1,
																			   (*sequence).CD.Dbox,(*sequence).CD.DPos+1,(*sequence).CD.probT);
													if (argS.output_key == 1){
														fprintf((*output),"%s_%d C=%d D=%d %d %d %s %d %s %d %.2f C/D box snoRNA\n%s\n",(*sequence).firstName,*id,(*sequence).CD.CPos+1-start,(*sequence).CD.DPos+1-start, start+1, end+1, (*sequence).CD.Cbox, (*sequence).CD.CPos+1,
																			   (*sequence).CD.Dbox,(*sequence).CD.DPos+1,(*sequence).CD.probT, (*sequence).CD.cand);
														*id+=1;
													}
													if (argS.ps == 1){
														sprintf(tmp,"%s_%d.ps",(*sequence).firstName,*id);
														PS_rna_plot((*sequence).CD.cand,(*sequence).Cstr,tmp);
													}  
																			 
												}
											 }
											 else{
												 if ((*sequence).CD.pred == 1){
													printf("%s_%d\t%d\t%d\t%s\t%d\t%s\t%d\t%.2f\t C/D box snoRNA\n",(*sequence).firstName,*id,start+1,end+1,(*sequence).CD.Cbox,(*sequence).CD.CPos+1,
																			   (*sequence).CD.Dbox,(*sequence).CD.DPos+1,(*sequence).CD.probT);
													if (argS.output_key == 1){
														fprintf((*output),"%s_%d C=%d D=%d %d %d %s %d %s %d %.2f C/D box snoRNA\n%s\n",(*sequence).firstName,*id,(*sequence).CD.CPos+1-start,(*sequence).CD.DPos+1-start, start+1, end+1, (*sequence).CD.Cbox, (*sequence).CD.CPos+1,
																			   (*sequence).CD.Dbox,(*sequence).CD.DPos+1,(*sequence).CD.probT, (*sequence).CD.cand);
													    *id+=1;
													}
													if (argS.ps == 1){
														sprintf(tmp,"%s_%d.ps",(*sequence).firstName,*id);
														PS_rna_plot((*sequence).CD.cand,(*sequence).Cstr,tmp);
													}  
												 }
												 else{
													printf("%s\t%d\t%d\t%s\t%d\t%s\t%d\t%.2f\t Unknown\n",(*sequence).firstName ,start+1,end+1,(*sequence).CD.Cbox,(*sequence).CD.CPos+1,
																			   (*sequence).CD.Dbox,(*sequence).CD.DPos+1,(*sequence).CD.probT); 
												 }
											 }
											 
										}
									
										cont++;	
										free((*sequence).CD.cand);
										free((*sequence).str);
										free((*sequence).Cstr);
									} else if (argS.verbose){
											printf("\t\t\tThe candidate did not pass on sec structure test\n");
									}
								 }
								  
							 } else if (argS.verbose){
								printf ("\t\t\tThe candidate did not pass on Kink turn test\n");	
							 }
							 

						} else if (argS.verbose){
							printf ("\t\t\tThe candidate did not pass on Kink turn test\n");	
     				    }
						 
					} else if (argS.verbose){
						printf ("\t\t\tThe candidate did not pass on Kink turn test\n");	
					}
				}
				
			}
		}
		
	}
	
	//printf ("%d ",cont);
	return 1;
}

