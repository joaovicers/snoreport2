#ifndef LFOLDING_H
#define LFOLDING_H



int lfold_sequence(char *seqH);

#endif

