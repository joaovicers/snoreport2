
#include "HACAbox.h"

#define basefilename "/home/joaovicers/c_snoReport/models/"
#define SEQ (*sequence)


/****************Dinucleotide content*/

float NTcontent(char *s,char n1, char n2){
	int i,size;
	float g,c,a,t;
	float gc=0;
	g=c=a=t=0;
	
	size = strlen(s);
	
	for (i=0; i<size;i++){
		switch(s[i]){
			case 'a':
			case 'A':
				a++;
				break;
			case 't':
			case 'T':	
			case 'U':	
			case 'u':	
				t++;
				break;
			case 'c':
			case 'C':
				c++;
				break;
			case 'g':
			case 'G':
				g++;
				break;
		}
		
	}
	if (n1 == 'a') n1=a;
	if (n1 == 'c') n1=c;
	if (n1 == 't') n1=t;
	if (n1 == 'g') n1=g;
	
	if (n2 == 'a') n2=a;
	if (n2 == 'c') n2=c;
	if (n2 == 't') n2=t;
	if (n2 == 'g') n2=g;
	
	
	gc = (float) ((n1+n2)/(a+t+c+g));
	return gc;
}
/*********************************/



float scoreH(char *Hbox) { 

	int i, m=6;
	float Hscore = 0,box[6][15] = {
			//		A		C		G		U		position:
				{0.9558, 0.0128, 0.0223, 0.0091},	// 0
				{0.25  , 0.25  , 0.25  , 0.25  },	// 1
				{0.9774, 0.0057, 0.0134, 0.0035},	// 2
				{0.25  , 0.25  , 0.25  , 0.25  },	// 3
				{0.25  , 0.25  , 0.25  , 0.25  },	// 4
				{0.8025, 0.0472, 0.1216, 0.0287}	// 5
	};

	box[0][4]  = (box[0][0]+box[0][2])/2; // R
	box[0][5]  = (box[0][1]+box[0][3])/2; // Y
	box[0][6]  = (box[0][0]+box[0][1])/2; // M
	box[0][7]  = (box[0][2]+box[0][3])/2; // K
	box[0][8]  = (box[0][0]+box[0][3])/2; // W
	box[0][9]  = (box[0][1]+box[0][2])/2; // S
	box[0][10] = (box[0][1]+box[0][2]+box[0][3])/3; // B
	box[0][11] = (box[0][0]+box[0][2]+box[0][3])/3; // D
	box[0][12] = (box[0][0]+box[0][1]+box[0][3])/3; // H
	box[0][13] = (box[0][0]+box[0][1]+box[0][2])/3; // V
	box[0][14] = 0.25; //N
	box[1][4]  = (box[1][0]+box[1][2])/2; // R
	box[1][5]  = (box[1][1]+box[1][3])/2; // Y
	box[1][6]  = (box[1][0]+box[1][1])/2; // M
	box[1][7]  = (box[1][2]+box[1][3])/2; // K
	box[1][8]  = (box[1][0]+box[1][3])/2; // W
	box[1][9]  = (box[1][1]+box[1][2])/2; // S
	box[1][10] = (box[1][1]+box[1][2]+box[1][3])/3; // B
	box[1][11] = (box[1][0]+box[1][2]+box[1][3])/3; // D
	box[1][12] = (box[1][0]+box[1][1]+box[1][3])/3; // H
	box[1][13] = (box[1][0]+box[1][1]+box[1][2])/3; // V
	box[1][14] = 0.25; //N
	box[2][4]  = (box[2][0]+box[2][2])/2; // R
	box[2][5]  = (box[2][1]+box[2][3])/2; // Y
	box[2][6]  = (box[2][0]+box[2][1])/2; // M
	box[2][7]  = (box[2][2]+box[2][3])/2; // K
	box[2][8]  = (box[2][0]+box[2][3])/2; // W
	box[2][9]  = (box[2][1]+box[2][2])/2; // S
	box[2][10] = (box[2][1]+box[2][2]+box[2][3])/3; // B
	box[2][11] = (box[2][0]+box[2][2]+box[2][3])/3; // D
	box[2][12] = (box[2][0]+box[2][1]+box[2][3])/3; // H
	box[2][13] = (box[2][0]+box[2][1]+box[2][2])/3; // V
	box[2][14] = 0.25; //N
	box[3][4]  = (box[3][0]+box[3][2])/2; // R
	box[3][5]  = (box[3][1]+box[3][3])/2; // Y
	box[3][6]  = (box[3][0]+box[3][1])/2; // M
	box[3][7]  = (box[3][2]+box[3][3])/2; // K
	box[3][8]  = (box[3][0]+box[3][3])/2; // W
	box[3][9]  = (box[3][1]+box[3][2])/2; // S
	box[3][10] = (box[3][1]+box[3][2]+box[3][3])/3; // B
	box[3][11] = (box[3][0]+box[3][2]+box[3][3])/3; // D
	box[3][12] = (box[3][0]+box[3][1]+box[3][3])/3; // H
	box[3][13] = (box[3][0]+box[3][1]+box[3][2])/3; // V
	box[3][14] = 0.25; //N
	box[4][4]  = (box[4][0]+box[4][2])/2; // R
	box[4][5]  = (box[4][1]+box[4][3])/2; // Y
	box[4][6]  = (box[4][0]+box[4][1])/2; // M
	box[4][7]  = (box[4][2]+box[4][3])/2; // K
	box[4][8]  = (box[4][0]+box[4][3])/2; // W
	box[4][9]  = (box[4][1]+box[4][2])/2; // S
	box[4][10] = (box[4][1]+box[4][2]+box[4][3])/3; // B
	box[4][11] = (box[4][0]+box[4][2]+box[4][3])/3; // D
	box[4][12] = (box[4][0]+box[4][1]+box[4][3])/3; // H
	box[4][13] = (box[4][0]+box[4][1]+box[4][2])/3; // V
	box[4][14] = 0.25; //N
	box[5][4]  = (box[5][0]+box[5][2])/2; // R
	box[5][5]  = (box[5][1]+box[5][3])/2; // Y
	box[5][6]  = (box[5][0]+box[5][1])/2; // M
	box[5][7]  = (box[5][2]+box[5][3])/2; // K
	box[5][8]  = (box[5][0]+box[5][3])/2; // W
	box[5][9]  = (box[5][1]+box[5][2])/2; // S
	box[5][10] = (box[5][1]+box[5][2]+box[5][3])/3; // B
	box[5][11] = (box[5][0]+box[5][2]+box[5][3])/3; // D
	box[5][12] = (box[5][0]+box[5][1]+box[5][3])/3; // H
	box[5][13] = (box[5][0]+box[5][1]+box[5][2])/3; // V
	box[5][14] = 0.25; //N

	for(i=0; i<m; i++) {
		if(Hbox[i] == 'A') { Hscore += box[i][0]; }
		else if(Hbox[i] == 'C') { Hscore += box[i][1]; }
		else if(Hbox[i] == 'G') { Hscore += box[i][2]; }
		else if(Hbox[i] == 'U') { Hscore += box[i][3]; }
		else if(Hbox[i] == 'T') { Hscore += box[i][3]; }
		else if(Hbox[i] == 'R') { Hscore += box[i][4]; }
		else if(Hbox[i] == 'Y') { Hscore += box[i][5]; }
		else if(Hbox[i] == 'M') { Hscore += box[i][6]; }
		else if(Hbox[i] == 'K') { Hscore += box[i][7]; }
		else if(Hbox[i] == 'W') { Hscore += box[i][8]; }
		else if(Hbox[i] == 'S') { Hscore += box[i][9]; }
		else if(Hbox[i] == 'B') { Hscore += box[i][10]; }
		else if(Hbox[i] == 'D') { Hscore += box[i][11]; }
		else if(Hbox[i] == 'H') { Hscore += box[i][12]; }
		else if(Hbox[i] == 'V') { Hscore += box[i][13]; }
		else { Hscore += box[i][14]; }
	}

	Hscore /= m;
	return Hscore;

}
float scoreA(char *Abox) {
	int i,m=3;
	float Ascore = 0,box[3][15] = {
		//		A		C		G		U		   position:
		    {0.9999, 0.0000, 0.0001, 0.0000},		//1
		    {0.0448, 0.7840, 0.0315, 0.1396},		//2
		    {0.9998, 0.0002, 0.0000, 0.0000},		//3
	};

    box[0][4]  = (box[0][0]+box[0][2])/2; // R
    box[0][5]  = (box[0][1]+box[0][3])/2; // Y
    box[0][6]  = (box[0][0]+box[0][1])/2; // M
    box[0][7]  = (box[0][2]+box[0][3])/2; // K
    box[0][8]  = (box[0][0]+box[0][3])/2; // W
    box[0][9]  = (box[0][1]+box[0][2])/2; // S
    box[0][10] = (box[0][1]+box[0][2]+box[0][3])/3; // B
    box[0][11] = (box[0][0]+box[0][2]+box[0][3])/3; // D
    box[0][12] = (box[0][0]+box[0][1]+box[0][3])/3; // H
    box[0][13] = (box[0][0]+box[0][1]+box[0][2])/3; // V
    box[0][14] = 0.25; //N
    box[1][4]  = (box[1][0]+box[1][2])/2; // R
    box[1][5]  = (box[1][1]+box[1][3])/2; // Y
    box[1][6]  = (box[1][0]+box[1][1])/2; // M
    box[1][7]  = (box[1][2]+box[1][3])/2; // K
    box[1][8]  = (box[1][0]+box[1][3])/2; // W
    box[1][9]  = (box[1][1]+box[1][2])/2; // S
    box[1][10] = (box[1][1]+box[1][2]+box[1][3])/3; // B
    box[1][11] = (box[1][0]+box[1][2]+box[1][3])/3; // D
    box[1][12] = (box[1][0]+box[1][1]+box[1][3])/3; // H
    box[1][13] = (box[1][0]+box[1][1]+box[1][2])/3; // V
    box[1][14] = 0.25; //N
    box[2][4]  = (box[2][0]+box[2][2])/2; // R
    box[2][5]  = (box[2][1]+box[2][3])/2; // Y
    box[2][6]  = (box[2][0]+box[2][1])/2; // M
    box[2][7]  = (box[2][2]+box[2][3])/2; // K
    box[2][8]  = (box[2][0]+box[2][3])/2; // W
    box[2][9]  = (box[2][1]+box[2][2])/2; // S
    box[2][10] = (box[2][1]+box[2][2]+box[2][3])/3; // B
    box[2][11] = (box[2][0]+box[2][2]+box[2][3])/3; // D
    box[2][12] = (box[2][0]+box[2][1]+box[2][3])/3; // H
    box[2][13] = (box[2][0]+box[2][1]+box[2][2])/3; // V
    box[2][14] = 0.25; //N

    for(i=0; i<m; i++) {
    	if(Abox[i] == 'A') { Ascore += box[i][0]; }
    	else if(Abox[i] == 'C') { Ascore += box[i][1]; }
    	else if(Abox[i] == 'G') { Ascore += box[i][2]; }
    	else if(Abox[i] == 'U') { Ascore += box[i][3]; }
    	else if(Abox[i] == 'T') { Ascore += box[i][3]; }
    	else if(Abox[i] == 'R') { Ascore += box[i][4]; }
    	else if(Abox[i] == 'Y') { Ascore += box[i][5]; }
    	else if(Abox[i] == 'M') { Ascore += box[i][6]; }
    	else if(Abox[i] == 'K') { Ascore += box[i][7]; }
    	else if(Abox[i] == 'W') { Ascore += box[i][8]; }
    	else if(Abox[i] == 'S') { Ascore += box[i][9]; }
    	else if(Abox[i] == 'B') { Ascore += box[i][10]; }
    	else if(Abox[i] == 'D') { Ascore += box[i][11]; }
    	else if(Abox[i] == 'H') { Ascore += box[i][12]; }
    	else if(Abox[i] == 'V') { Ascore += box[i][13]; }
    	else { Ascore += box[i][14]; }
    }

    Ascore /= m;
	return Ascore;
}

/**returns the position of the largest substructure found in Lfold**/ 
int lfoldResult(){
	FILE *FP;
	char tmpSeq[300],tmp[50];
	int max=0,maxPos=0,pos=0,lenSeq;
	int i;
	
	FP = fopen("stdout","r"); //temporary file with the substructures
	if (FP == NULL){
		puts ("error\n");
		return 1;
	}

	while (fscanf(FP,"%s %[^\n]s\n",tmpSeq,tmp)!=EOF){
		for (i=strlen(tmp)-1;i>0;i--){
			if (tmp[i] == ' '){ 
				break;
			}
		}
		pos = atoi(tmp+i+1);
		lenSeq = strlen(tmpSeq);
		//printf ("%s length %d pos = %d\n",tmpSeq,lenSeq,pos); getchar();
		if (lenSeq > max){
			max = lenSeq;
			maxPos = pos;
		}
	
	}
	fclose(FP);
	
	
	
	return maxPos;
}

/***************************Hairpin Verifier********************************/

int hairpin_verifier(char *strCons){
		int i,j,loops=0,stem=0,endStem=-1,hairpinOpen=0,pair=0;
		
		
	for (i = 0; i < strlen(strCons);i++){

		if ((strCons[i] == '(') && (hairpinOpen==0)){
			hairpinOpen=1;
			stem++;

		}
		else if (strCons[i] == '('){
			stem++;
			if (pair == 1){
				return 0; //hairpin inside in another hairpin or two hairpins before the box
			}
		}
		else if (strCons[i] == ')'){
			stem--;
			pair = 1;
		}
	
		if ((strCons[i] == '.') && (strCons[i+1] == ')')){
			loops++;
		}

		if ((hairpinOpen == 1) && (stem == 0)){ 
			endStem=i;
		}
	}
	if (loops >= 2){
		if (((strCons[strlen(strCons) - 20]=='.'))){ //find if the 14th nt is inside the loop
			for (j=strlen(strCons) - 20; j > 0 ;j--){
				if (strCons[j] == '('){
					return 0; // it isn't the recognition pocket
				}
				if (strCons[j] == ')'){ 
						break;
				}
			}
			for (j=strlen(strCons) - 20; j < strlen(strCons) ;j++){
				if (strCons[j] == ')'){ 
						return 1;
				}
			}
			return 0;
		}
	}

	return 0;
	
}
/*********************PrintHACAfeatures********************************/
void printHACAfeatures(HACAinfo HACA,argument argS){

	printf("%d 1:%f",argS.class,HACA.mfe);
	printf(" 2:%f",HACA.mfeCH);
	printf(" 3:%f",HACA.mfeCA);
	printf(" 4:%f",HACA.AC);
	printf(" 5:%f",HACA.GC);
	printf(" 6:%f",HACA.GU);
	printf(" 7:%f",HACA.zscoreH);
	printf(" 8:%f",HACA.zscoreA);
	printf(" 9:%f",HACA.Hscore);
	printf(" 10:%f",HACA.Ascore);
	printf(" 11:%d",(int) strlen(HACA.seqH));
	printf(" 12:%d",(int) strlen(HACA.seqA));
	printf(" 13:%f",HACA.LloopSC);
	printf(" 14:%f",HACA.RloopSC);
	printf(" 15:%f",HACA.LloopYC);
	printf(" 16:%f",HACA.RloopYC);
	printf(" 17:%f",HACA.lloopSym);
	printf(" 18:%f\n",HACA.rloopSym);

}



/*********************************************extractFeaturesHACA**************************************************/

int  extractFeaturesHACA(seqinfo *sequence, argument argS, struct svm_model *HACAmodel,FILE **output,int *id){
	int i,j,k,l,r,m,n;
	int stem, nLoops;
	int start,start_,len;
	char command[400],tmp[500],tmpSeq[600];
	
	
	if (argS.verbose){
		printf("%s\n",SEQ.seqName);
	}
	
    /********************Detect H box candidates*********/	
	for (i=40;i<SEQ.tamSeq-52;i++){
		memcpy(SEQ.HACA.Hbox,SEQ.seq+i,6);
		SEQ.HACA.Hbox[6]='\0';
		SEQ.HACA.Hpos=i;
		SEQ.HACA.Hscore=scoreH(SEQ.HACA.Hbox);
		
		if (SEQ.HACA.Hscore >= SEQ.HACA.Hthreshold){
			if (argS.verbose == 1){
				printf("\tHbox = %s  Hpos = %d score = %f\n",SEQ.HACA.Hbox,SEQ.HACA.Hpos+1,SEQ.HACA.Hscore);
			}
			/*********filter structure for the first hairpin loop****************/
			//find stem loop before Hbox candidate
			start = SEQ.HACA.Hpos-200;
			if ( start < 0){
				start =0;
			}
			
			start_ = start;
			SEQ.HACA.seqH = (char *) calloc(SEQ.HACA.Hpos-start+7,sizeof(char));
			memcpy(SEQ.HACA.seqH,SEQ.seq+start,SEQ.HACA.Hpos-start);
			
			
			memset(command,0,400);
			strcpy(command,getenv("SNOREPORTMODELS"));
			strcat(command,"../");
			strcat(command,"lfolding/lfolding ");
			strcat(command,SEQ.HACA.seqH);
			strcat(command," >stdout");

			/*need to change this in the future due its security vulnerability*/
			system(command);
			/* ******************************  */
			start = lfoldResult();
		
			//printf ("%s\n",SEQ.HACA.seqH);
			strcpy(SEQ.HACA.seqH,SEQ.HACA.seqH+start-1);
			
			strcat(SEQ.HACA.seqH,SEQ.HACA.Hbox);
			
			
			SEQ.HACA.conH = (char *) calloc(strlen(SEQ.HACA.seqH)+1,sizeof(char));
			
			len = strlen(SEQ.HACA.seqH);
			for (j=0;j< len;j++){
				SEQ.HACA.conH[j]='.';
			}

			
			for(j=0;j<6;j++){
				SEQ.HACA.conH[len-1-j]='x';
			}
						
			SEQ.HACA.conH[len-20]='x';
			
			SEQ.HACA.strCH = (char *) calloc(strlen(SEQ.HACA.seqH)+1,sizeof(char));
			
			strcpy(SEQ.HACA.strCH,SEQ.HACA.conH);
			
			SEQ.HACA.mfeCH=foldCSequence(SEQ.HACA.seqH,&SEQ.HACA.strCH);
			
			
			//filter secondary structure from seqH
			if (!(hairpin_verifier(SEQ.HACA.strCH))){
				if (argS.verbose){
					printf("\t\tIt did not pass on Sec structure filter\n");
				}
				continue;
			}
	
			if (argS.verbose){
				printf("\t%s\n",SEQ.HACA.seqH);
				printf("\t%s\n",SEQ.HACA.strCH);
			}
			/*************Detect ACA box candidates*************************/
			
			for (j = i+45;j<SEQ.tamSeq-5;j++){
				if ((j - i +45) > 120){
					break;
				}
				memcpy(SEQ.HACA.Abox,SEQ.seq+j,3);
				SEQ.HACA.Abox[3]='\0';
				SEQ.HACA.Apos=j;
				SEQ.HACA.Ascore = scoreA(SEQ.HACA.Abox);
				
				if (SEQ.HACA.Ascore >= SEQ.HACA.Athreshold){
					
					if (argS.verbose == 1){
						printf ("\t\tACA box = %s pos=%d score = %f \n",SEQ.HACA.Abox, SEQ.HACA.Apos+1, SEQ.HACA.Ascore);
					}
					/*****fold  the sequence between H nd ACA box*******/
					SEQ.HACA.seqA = (char *) calloc(((SEQ.HACA.Apos+7) - (SEQ.HACA.Hpos+6)),sizeof(char));
					SEQ.HACA.strCA = (char *) calloc(((SEQ.HACA.Apos+7) - (SEQ.HACA.Hpos+6)),sizeof(char));
					SEQ.HACA.conA = (char *) calloc(((SEQ.HACA.Apos+7) - (SEQ.HACA.Hpos+6)),sizeof(char));
					
					
					memcpy(SEQ.HACA.seqA,SEQ.seq+(SEQ.HACA.Hpos+6), (SEQ.HACA.Apos+6) - (SEQ.HACA.Hpos+6));
					
					
					len = strlen(SEQ.HACA.seqA);
					for (k=0;k < len-6;k++){
						SEQ.HACA.strCA[k] = '.';
					}
					
					for (k=len-6;k < len;k++){
						SEQ.HACA.strCA[k] = 'x';
					}
					SEQ.HACA.strCA[len-20]='x';
					strcpy(SEQ.HACA.conA,SEQ.HACA.strCA);
					
					SEQ.HACA.mfeCA = foldCSequence(SEQ.HACA.seqA, &SEQ.HACA.strCA);
					
					//filter secondary structure from seqA
					if (!(hairpin_verifier(SEQ.HACA.strCA))){
						if (argS.verbose){
							printf("\t\t\t It did not pass on the Sec structure filter\n");
						}
						continue;
					}
					
					SEQ.seqCand = (char *) calloc(strlen(SEQ.HACA.seqH)+strlen(SEQ.HACA.seqA)+1,sizeof(char));
					SEQ.con = (char *) calloc(strlen(SEQ.HACA.seqH)+strlen(SEQ.HACA.seqA)+1,sizeof(char));
					strcpy(SEQ.seqCand,SEQ.HACA.seqH);
					strcat(SEQ.seqCand,SEQ.HACA.seqA);
					SEQ.HACA.mfe = foldSequence(SEQ.seqCand,&SEQ.con);
					
					SEQ.HACA.AC = NTcontent(SEQ.seqCand,'a','c');
					SEQ.HACA.GC = NTcontent(SEQ.seqCand,'g','c');
					SEQ.HACA.GU = NTcontent(SEQ.seqCand,'g','t');
					
					//zscoreH												  
					regression_svm_init(getenv("SNOREPORTMODELS"));
					predict_values(SEQ.HACA.seqH,&(SEQ.HACA.Eavg),&(SEQ.HACA.Estdv));
					SEQ.HACA.zscoreH = mfe_zscore(SEQ.HACA.seqH,SEQ.HACA.mfeCH);
					regression_svm_free();
					//zscoreA												  
					regression_svm_init(getenv("SNOREPORTMODELS"));
					predict_values(SEQ.HACA.seqA,&(SEQ.HACA.Eavg),&(SEQ.HACA.Estdv));
					SEQ.HACA.zscoreA = mfe_zscore(SEQ.HACA.seqA,SEQ.HACA.mfeCA);
					regression_svm_free();					
					
					
					//collect features from the left stem Loop
					//recognition pocket
					k=strlen(SEQ.HACA.strCH)-20;
					l=0; r=0;
					while(SEQ.HACA.strCH[k] == '.'){
						k++;
					}
					k--;
					while (SEQ.HACA.strCH[k] == '.' ){
						k--; r++;
					}
					stem=1;
					k--;
					while (stem != 0){
						switch(SEQ.HACA.strCH[k]){
							case ')': stem++; k--; break;
							case '.': k--;         break;
							case '(': stem--; k--; break;
						}
					}
					while (SEQ.HACA.strCH[k] == '.'){
						k--;l++;
					}

					SEQ.HACA.LloopSC = l + r;
					SEQ.HACA.LloopYC = (float) (l-r) / (l+r);

					
					//Between H and ACA box
					k=strlen(SEQ.HACA.strCA)-20;
					l=0; r=0;
					while(SEQ.HACA.strCA[k] == '.'){
						k++;
					}
					k--;
					while (SEQ.HACA.strCA[k] == '.' ){
						k--; r++;
					}
					stem=1;
					k--;
					while (stem != 0){
						switch(SEQ.HACA.strCA[k]){
							case ')': stem++; k--; break;
							case '.': k--;         break;
							case '(': stem--; k--; break;
						}
					}
					while (SEQ.HACA.strCA[k] == '.'){
						k--;l++;
					}

					SEQ.HACA.RloopSC = l + r;
					SEQ.HACA.RloopYC = (float) (l-r) / (l+r);
					

					//lloopSym
					l=r=0;
					m=0;
					while ((m < strlen(SEQ.HACA.strCH)) && (SEQ.HACA.strCH[m] != ')' )){
						m++;
					}
					nLoops=0;
					SEQ.HACA.lloopSym=0;

					k=0;
					while (SEQ.HACA.strCH[k] != '('){ //search the first internal Loop
						k++;
					}

					while(k < m){
						if (SEQ.HACA.strCH[k]=='.'){
							stem=0;
							l=1;
							r=0;
							k++;
							while(SEQ.HACA.strCH[k] == '.'){
								l++;k++;
							}
							n=k;
							if (SEQ.HACA.strCH[n] == '('){
								stem=1;
								n++;
							}
							while(stem != 0){
								switch(SEQ.HACA.strCH[n]){
									case ')': stem--; n++; break;
									case '.': n++;         break;
									case '(': stem++; n++; break;
								}
							}
							while (SEQ.HACA.strCH[n] == '.'){
								if (n == strlen(SEQ.HACA.strCH)-20){ //rec pocket! don't calculate it;
									l=r=0; nLoops--; break;
								}
								r++; n++;

							}
							SEQ.HACA.lloopSym+=(l-r);
							nLoops++;
						}
						k++;
					}
					SEQ.HACA.lloopSym-=(l-r); // remove the hairpin loop;
					if (nLoops > 2){
						SEQ.HACA.lloopSym=SEQ.HACA.lloopSym/(nLoops-1); //-1 means to remove the hairpin loop
					}
					else {
						SEQ.HACA.lloopSym = 0;
					}
					
					//RloopSym
					l=r=0;
					m=0;
					while ((m < strlen(SEQ.HACA.strCA)) && (SEQ.HACA.strCA[m] != ')' )){
						m++;
					}
					nLoops=0;
					SEQ.HACA.rloopSym=0;

					k=0;
					while (SEQ.HACA.strCA[k] != '('){ //search the first internal Loop
						k++;
					}

					while(k < m){
						if (SEQ.HACA.strCA[k]=='.'){
							stem=0;
							l=1;
							r=0;
							k++;
							while(SEQ.HACA.strCA[k] == '.'){
								l++;k++;
							}
							n=k;
							if (SEQ.HACA.strCA[n] == '('){
								stem=1;
								n++;
							}
							while(stem != 0){
								switch(SEQ.HACA.strCA[n]){
									case ')': stem--; n++; break;
									case '.': n++;         break;
									case '(': stem++; n++; break;
								}
							}
							while (SEQ.HACA.strCA[n] == '.'){
								if (n == strlen(SEQ.HACA.strCA)-20){ //rec pocket! don't calculate it;
									l=r=0; nLoops--; break;
								}
								r++; n++;

							}
							SEQ.HACA.rloopSym+=(l-r);
							nLoops++;
						}
						k++;
					}
					SEQ.HACA.rloopSym-=(l-r); // remove the hairpin loop;
					if (nLoops > 2){
						SEQ.HACA.rloopSym=SEQ.HACA.rloopSym/(nLoops-1); //-1 means to remove the hairpin
					}
					else {
						SEQ.HACA.rloopSym = 0;
					}
					
					if (argS.verbose == 1){
						printf("\t\t%s\n",SEQ.HACA.seqA); 
						printf("\t\t%s\n",SEQ.HACA.strCA); 
					}
					if (argS.trainHACA){
						printf("#%s H=%d ACA=%d\n",SEQ.seqName,SEQ.HACA.Hpos+1, SEQ.HACA.Apos+1);
						printHACAfeatures(SEQ.HACA,argS);
					}
					else{
						SEQ.HACA.pred = predictHACA(&SEQ.HACA,HACAmodel);
						if (argS.positives == 1){
							if (SEQ.HACA.pred == 1){
								printf("%s_%d\t%d\t%d\t%s\t%d\t%s\t%d\t%f\tH/ACA box snoRNA\n",SEQ.firstName,*id, start_+start+2,SEQ.HACA.Apos+3,SEQ.HACA.Hbox,SEQ.HACA.Hpos+1
																   ,SEQ.HACA.Abox,SEQ.HACA.Apos+1,SEQ.HACA.probT);
								if (argS.output_key == 1){
									fprintf((*output),"%s_%d Hpos=%d ACApos=%d %d %d %s %d %s %d %.2f H/ACA box snoRNA\n%s%s\n",SEQ.firstName,*id,SEQ.HACA.Hpos-(start_+start)+2,SEQ.HACA.Apos-(start_+start)+2,start_+start+2,SEQ.HACA.Apos+3,SEQ.HACA.Hbox,SEQ.HACA.Hpos+1
																   ,SEQ.HACA.Abox,SEQ.HACA.Apos+1,SEQ.HACA.probT,SEQ.HACA.seqH,SEQ.HACA.seqA);
									*id+=1;
								}
								if (argS.ps == 1){
									sprintf(tmp,"%s_%d.ps",SEQ.firstName,*id);
									sprintf(tmpSeq,"%s%s",SEQ.HACA.strCH,SEQ.HACA.strCA);
									PS_rna_plot(SEQ.seqCand,tmpSeq,tmp);
								}  
							}
						}
						else{
							if (SEQ.HACA.pred == 1){
								printf("%s_%d\t%d\t%d\t%s\t%d\t%s\t%d\t%f\tH/ACA box snoRNA\n",SEQ.firstName,*id, start_+start+2,SEQ.HACA.Apos+3,SEQ.HACA.Hbox,SEQ.HACA.Hpos+1
																   ,SEQ.HACA.Abox,SEQ.HACA.Apos+1,SEQ.HACA.probT);
								if (argS.output_key == 1){
									fprintf((*output),"%s_%d Hpos=%d ACApos=%d %d %d %s %d %s %d %.2f H/ACA box snoRNA\n%s%s\n",SEQ.firstName,*id,SEQ.HACA.Hpos-(start_+start)+2,SEQ.HACA.Apos-(start_+start)+2,start_+start+2,SEQ.HACA.Apos+3,SEQ.HACA.Hbox,SEQ.HACA.Hpos+1
																   ,SEQ.HACA.Abox,SEQ.HACA.Apos+1,SEQ.HACA.probT,SEQ.HACA.seqH,SEQ.HACA.seqA);
									*id+=1;
								}
								if (argS.ps == 1){
									sprintf(tmp,"%s_%d.ps",SEQ.firstName,*id);
									sprintf(tmpSeq,"%s%s",SEQ.HACA.strCH,SEQ.HACA.strCA);
									PS_rna_plot(SEQ.seqCand,tmpSeq,tmp);
								}  
							}
							else{
								printf("%s\t%d\t%d\t%s\t%d\t%s\t%d\t%f\tUnknown\n",SEQ.firstName, start_+start+2,SEQ.HACA.Apos+3,SEQ.HACA.Hbox,SEQ.HACA.Hpos+1
																   ,SEQ.HACA.Abox,SEQ.HACA.Apos+1,SEQ.HACA.probT);
							}
						}
					}	
					
					free(SEQ.seqCand);
					free(SEQ.HACA.seqA);
					free(SEQ.HACA.conA);
					free(SEQ.HACA.strCA);
					

				}
			}
			free(SEQ.HACA.seqH);
			free(SEQ.HACA.conH);
			free(SEQ.HACA.strCH);

			
			
		}
	}		
	
	
	return 1;
}
