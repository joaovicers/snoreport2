g++ ./lfolding/lfolding.cpp -I/usr/include/ViennaRNA/ -L/usr/include/ViennaRNA/ -lRNA -lm -fopenmp -o ./lfolding/lfolding

make rm
make all

