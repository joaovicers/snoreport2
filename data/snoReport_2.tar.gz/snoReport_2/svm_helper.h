/*********************************************************************
 *                                                                   *
 *                          svm_helper.h                             *
 *                                                                   *
 *   Functions relating to SVM regression/classification and         *
 *    for interacting with the SVMLIB libraries                      *
 *                                                                   *
 *	          c Stefan Washietl, Ivo L Hofacker,					 *
 * 				João Victor de Araujo Oliveira		                 *
 *                                                                   *
 *	   $Id: svm_helper.h,v 1.3 2004/09/19 13:31:41 wash Exp $	     *
 *                                                                   *
 *********************************************************************/
#ifndef SVMHELPER_H_
#define SVMHELPER_H_

#include "svm.h"

/*
  declare svm_model for other functions (declaration is only in
  svmlib/svm.cpp and not in svmlib/svm.h)
*/

void get_regression_models(struct svm_model** avg_model,
						   struct svm_model** stdv_model,
						   char *basefilename);

struct svm_model* get_decision_modelHACA(char *basefilename);

struct svm_model* get_decision_modelCD(char *basefilename);

struct svm_model* default_avg_model();

struct svm_model* default_stdv_model();

struct svm_model* default_decision_model();

void scale_node_linear(struct svm_node* node,double scale[][2]);

void scale_regression_node(struct svm_node* node);

void scale_decision_node(struct svm_node* node);

void backscale_regression(double* avg, double* stdv);

#endif /* SVMHELPER_H_ */
