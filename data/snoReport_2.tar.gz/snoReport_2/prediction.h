#ifndef PREDICTION
#define PREDICTION

#include "structures.h"
#include "svm.h"
#include "svm_helper.h"

int predictCD(CDinfo *CD,struct svm_model *CDmodel);
int predictHACA(HACAinfo *HACA,struct svm_model *HACAmodel);

#endif
