#ifndef ARGUMENTS_H
#define ARGUMENTS_H

#include "structures.h"


int parseArgs(argument *argS,int numArgs,char **args);


#endif
