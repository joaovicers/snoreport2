#ifndef HACABOX_H
#define HACABOX_H

#include "structures.h"
#include "zscore.h"
#include "prediction.h"

int  extractFeaturesHACA(seqinfo *sequence, argument argS, struct svm_model *HACAmodel,FILE **output,int *id);


#endif
