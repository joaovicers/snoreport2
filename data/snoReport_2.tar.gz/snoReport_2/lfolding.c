#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "Lfold.h"
#include "fold_vars.h"
#include "utils.h"


int lfold_sequence(char *seqH){
	char *structure;
	
	structure = (char *) calloc(strlen(seqH)+1,sizeof(char));
	
	
	//Lfold(seqH,structure,120);
	
	return 0;
}

