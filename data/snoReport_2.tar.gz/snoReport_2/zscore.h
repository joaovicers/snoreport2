/*********************************************************************
 *                                                                   *
 *                              zscore.h                             *
 *                                                                   *
 *	Compute a z-score to assess significance of a predicted MFE  *
 *                                                                   *
 *	          c Stefan Washietl, Ivo L Hofacker                  *
 *                                                                   *
 *	   $Id: zscore.h,v 1.3 2004/09/19 13:31:42 wash Exp $        *
 *                                                                   *
 *********************************************************************/

#ifndef ZSCORE_H
#define ZSCORE_H

#include "svm.h"
#include "svm_helper.h"



void regression_svm_init(char *basefilename);

void regression_svm_free();

double mfe_zscore(const char *seq,double mfe);

void predict_values(const char *seq, double *avg, double *stdv);



#endif
