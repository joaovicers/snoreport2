#ifndef STRUCTURES_H
#define STRUCTURES_H


#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
#include "folding.h"



typedef struct {
	char fasta[1000];
	char output[1000];
	int output_key;
	int haca;
	int cd;
	int positives;
	int trainHACA;
	int trainCD;
	int class;
	int verbose;
	int ps;	
}argument;



typedef struct{
	float mfe;
	float mfeC;
	float GC;
	char Cbox[8];
	int CPos;
	//char Dpbox[5]; // box D'
	//int DpPos;
	//char Cpbox[8]; // box C'
	//int CpPos;
	char Dbox[5];
	int DPos;
	double Eavg;
	double Estdv;
	float zscore;
	int ls;
	int l1;
	int bpStem;
	int lu5;
	int lu3;
	int stemUnpCbox;
	int stemUnpDbox;
	int wc2Stem;
	int u2Cbox;
	int Dcd;
	float Cscore;
	float Dscore;
	float Cthreshold;
	float Dthreshold;
	char *cand;
	int pred;
	double probT;
}CDinfo;

typedef struct {
	char Hbox[7];
	char Abox[4];
	char *seqH;
	char *seqA;
	char *strCH;
	char *strCA;
	char *conH;
	char *conA;
	int Hpos;
	int Apos;
	float Hthreshold;
	float Athreshold;
	float Hscore;
	float Ascore;
	double zscoreH;
	double zscoreA;
	float AC,GC,GU;
	float mfeCH;
	float mfeCA;
	float mfe;
	double Estdv;
	double Eavg;
	float LloopS;
	float LloopSC;
	float RloopS;
	float RloopSC;
	float LloopY;
	float LloopYC;
	float RloopY;
	float RloopYC;
	float lloopSym; //Symmetry between the loops before H box
	float rloopSym;
	int pred;
	double probT;
}HACAinfo;



typedef struct {
	char *seqName;
	char firstName[500];
	char *seq;
	char *seqCand;
	char *con;
	char *str;
	char *Cstr;
	int tamSeq; //length of the sequence
	CDinfo CD;
	HACAinfo HACA;

}seqinfo;


#endif
