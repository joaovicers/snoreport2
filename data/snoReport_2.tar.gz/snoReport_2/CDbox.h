#ifndef CDBOX_H
#define CDBOX_H

#include "structures.h"
#include "zscore.h"
#include "prediction.h"

int extractFeaturesCD(seqinfo *sequence,argument argS, struct svm_model *CDmodel, FILE **output, int * id);

#endif
