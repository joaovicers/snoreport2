#include "prediction.h"


int predictCD(CDinfo *CD, struct svm_model *CDmodel){
	struct svm_node node[17];
	double value[2];
	int i,pred;
	double scale_decision_SCD[][2]= {
				{-101.099998, -1.4},
				{-16.09, -0.01},
				{-99.417361, -2.383107},
				{1.603282, 4.768336},
				{2, 10},
				{3, 183},
				{0.621857, 0.767514},
				{0.65625, 0.78125},
				{0.261905, 0.7727270000000001},
				{-1.774513, 20.59099},
				{3, 10},
				{0, 4},
				{0, 5},
				{0, 7},
				{0, 7},
				{0, 1},
	};




	node[0].index  = 1;   node[0].value  = (*CD).mfe;
	node[1].index  = 2;   node[1].value  = (*CD).mfeC;
	node[2].index  = 3;   node[2].value  = (*CD).Eavg;
	node[3].index  = 4;   node[3].value  = (*CD).Estdv;
	node[4].index  = 5;   node[4].value  = (*CD).ls;
	node[5].index  = 6;   node[5].value  = (*CD).Dcd;
	node[6].index  = 7;   node[6].value  = (*CD).Cscore;
	node[7].index  = 8;   node[7].value  = (*CD).Dscore;
	node[8].index  = 9;   node[8].value  = (*CD).GC;
	node[9].index  = 10;  node[9].value  = (*CD).zscore;
	node[10].index = 11;  node[10].value = (*CD).bpStem;
	node[11].index = 12;  node[11].value = (*CD).lu5;
	node[12].index = 13;  node[12].value = (*CD).lu3;
	node[13].index = 14;  node[13].value = (*CD).stemUnpCbox;
	node[14].index = 15;  node[14].value = (*CD).stemUnpDbox;
	node[15].index = 16;  node[15].value = (*CD).wc2Stem;
	node[16].index = -1;

	//scale
	scale_node_linear(node, scale_decision_SCD);
	pred = svm_predict_probability(CDmodel, node, value);
	
	(*CD).probT = value[0];
	
	return pred; 
	//printf("value 0 = %f\t value 1 = %f\n",value[0],value[1]);
	
}


int predictHACA(HACAinfo *HACA, struct svm_model *HACAmodel){
	struct svm_node node[19];
	double value[2];
	int i,pred;
	double scale_decision_SHACA[][2]= {
				{-81.599998, -8.5},
				{-51.099998, -0.3},
				{-40.400002, -0.1},
				{0.354839, 0.6018520000000001},
				{0.313043, 0.7651520000000001},
				{0.398148, 0.645161},
				{-6.743625, 4.442155},
				{-7.316256, 6.543503},
				{0.451983, 0.58095},
				{0.677067, 0.9278999999999999},
				{37, 133},
				{45, 75},
				{1, 30},
				{1, 30},
				{-1, 0.833333},
				{-1, 0.833333},
				{-3.5, 7},
				{-1, 8.5},
			 
	};

	node[0].index  = 1;   node[0].value  = (*HACA).mfe ;
	node[1].index  = 2;   node[1].value  = (*HACA).mfeCH;
	node[2].index  = 3;   node[2].value  = (*HACA).mfeCA;
	node[3].index  = 4;   node[3].value  = (*HACA).AC;
	node[4].index  = 5;   node[4].value  = (*HACA).GC;
	node[5].index  = 6;   node[5].value  = (*HACA).GU;
	node[6].index  = 7;   node[6].value  = (*HACA).zscoreH;
	node[7].index  = 8;   node[7].value  = (*HACA).zscoreA;
	node[8].index  = 9;   node[8].value  = (*HACA).Hscore;
	node[9].index  = 10;  node[9].value  = (*HACA).Ascore;
	node[10].index = 11;  node[10].value = (int) strlen((*HACA).seqH);
	node[11].index = 12;  node[11].value = (int) strlen((*HACA).seqA);
	node[12].index = 13;  node[12].value = (*HACA).LloopSC;
	node[13].index = 14;  node[13].value = (*HACA).RloopSC;
	node[14].index = 15;  node[14].value = (*HACA).LloopYC;
	node[15].index = 16;  node[15].value = (*HACA).RloopYC;
	node[16].index = 17;  node[16].value = (*HACA).lloopSym;
	node[17].index = 18;  node[17].value = (*HACA).rloopSym;
	node[18].index = -1;


	//scale
	scale_node_linear(node, scale_decision_SHACA);
	pred = svm_predict_probability(HACAmodel, node, value);
	
	(*HACA).probT = value[0];
	
	return pred; 
	
}
