
#include <iostream>
#include <fstream>
#include <algorithm>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <sstream>
extern "C"{
	#include "ViennaRNA/Lfold.h"
	#include "fold_vars.h"
    #include "utils.h"

}

using namespace std;


int main(int argc, char *argv[]) {
	string seq;
	string structure;
	char str[seq.length()];

	seq = argv[1];

	Lfold(seq.c_str(),str,120);

	return 0;
}
